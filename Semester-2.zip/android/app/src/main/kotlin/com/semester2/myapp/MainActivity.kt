package com.semester2.myapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
